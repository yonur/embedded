/**
 * \addtogroup helloworld
 * @{
 */

/**
 * \file
 *         An example of how to write uIP applications
 *         with protosockets.
 * \author
 *         Adam Dunkels <adam@sics.se>
 */

/*
 * This is a short example of how to write uIP applications using
 * protosockets.
 */

/*
 * We define the application state (struct hello_world_state) in the
 * hello-world.h file, so we need to include it here. We also include
 * uip.h (since this cannot be included in hello-world.h) and
 * <string.h>, since we use the memcpy() function in the code.
 */
#include "hello-world.h"
#include "drivers/pinout.h"
#include "uip.h"
#include <string.h>

uint32_t time = 0;
uint32_t pinVal=0;
/*
 * Declaration of the protosocket function that handles the connection
 * (defined at the end of the code).
 */
static int handle_connection(struct hello_world_state *s);
/*---------------------------------------------------------------------------*/
/*
 * The initialization function. We must explicitly call this function
 * from the system initialization code, some time after uip_init() is
 * called.
 */
void
hello_world_init(void)
{
  /* We start to listen for connections on TCP port 1000. */
  uip_listen(HTONS(6340));
}
/*---------------------------------------------------------------------------*/
/*
 * In hello-world.h we have defined the UIP_APPCALL macro to
 * hello_world_appcall so that this funcion is uIP's application
 * function. This function is called whenever an uIP event occurs
 * (e.g. when a new connection is established, new data arrives, sent
 * data is acknowledged, data needs to be retransmitted, etc.).
 */
void
hello_world_appcall(void)
{
  /*
   * The uip_conn structure has a field called "appstate" that holds
   * the application state of the connection. We make a pointer to
   * this to access it easier.
   */
  struct hello_world_state *s = &(uip_conn->appstate);

  /*
   * If a new connection was just established, we should initialize
   * the protosocket in our applications' state structure.
   */
  if(uip_connected()) {
    PSOCK_INIT(&s->p, s->inputbuffer, sizeof(s->inputbuffer));
  }

  /*
   * Finally, we run the protosocket function that actually handles
   * the communication. We pass it a pointer to the application state
   * of the current connection.
   */
  handle_connection(s);
}
/*---------------------------------------------------------------------------*/
/*
 * This is the protosocket function that handles the communication. A
 * protosocket function must always return an int, but must never
 * explicitly return - all return statements are hidden in the PSOCK
 * macros.
 */
static int
handle_connection(struct hello_world_state *s)
{
  PSOCK_BEGIN(&s->p);

  while(p_flag)
  {
	  PSOCK_SEND_STR(&s->p, "Hello. What is your name?\n");
	  PSOCK_READTO(&s->p, '\n');
	  strncpy(s->name, s->inputbuffer, sizeof(s->name));
	  if((s->name[0] == 'a') && (s->name[6] != 'q'))
	  {
		  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0, 1);
		  PSOCK_SEND_STR(&s->p, "Led is lighting\n");

		  while(((pinVal = GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_3)) & GPIO_PIN_3) == 0)
		  {
			  PSOCK_SEND_STR(&s->p, "No read PE3\n");
		  }
		  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0, 0);
		  PSOCK_SEND_STR(&s->p, "Led is no\n");
		  s->name[3] = 'c';
		  PSOCK_SEND_STR(&s->p, s->name);

		  TimerActivate();

		  while(t_ui32Flags)
		  {
			  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1, 2);
			  if(GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_4) && GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_5))
			  {
				  s->name[4] = 'x';
				  PSOCK_SEND_STR(&s->p, s->name);
			  }
			  time++;
		  }

		  TimerDeActivate();
		  t_ui32Flags = 1;
		  //2 sn bekleme yapacaz burada.
		  TimerActivate();

		  while(t_ui32Flags)
		  {

			  PSOCK_SEND_STR(&s->p, "Waiting\n");
			  time++;
		  }

		  TimerDeActivate();
		  t_ui32Flags = 1;
		  TimerActivate();

		  while(t_ui32Flags)
		  {
			  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1 | GPIO_PIN_2 , 6);
			  s->name[5] = 'w';
			  PSOCK_SEND_STR(&s->p, s->name);
			  time++;
		  }

		  TimerDeActivate();
		  t_ui32Flags = 1;
		  TimerActivate();

		  while(t_ui32Flags)
		  {

			  PSOCK_SEND_STR(&s->p, "Waiting\n");
			  time++;
		  }

		  TimerDeActivate();
		  t_ui32Flags = 1;
		  //2 sn bekleme yapacaz burada.
		  TimerActivate();

		  while(t_ui32Flags)
		  {
			  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1 | GPIO_PIN_2,0);
			  s->name[5] = 'z';
			  PSOCK_SEND_STR(&s->p, s->name);
			  time++;
		  }

		  TimerDeActivate();
		  t_ui32Flags = 1;

		  //GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_2, 4);
	  }
	  else if(s->name[6] == 'q')
	  {
		  p_flag = 0;
		  PSOCK_SEND_STR(&s->p, "Good bye and fuck you\n");
	  }
	  else
	  {
		  PSOCK_SEND_STR(&s->p, "Please enter a sentence that first letter is 'a'\n");
		  //PSOCK_READTO(&s->p, '\n');
	  }
  }

  PSOCK_CLOSE(&s->p);
  
  PSOCK_END(&s->p);
}
/*---------------------------------------------------------------------------*/
